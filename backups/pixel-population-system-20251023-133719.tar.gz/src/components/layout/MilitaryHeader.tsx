'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'

export function MilitaryHeader() {

  return (
    <header className="bg-gradient-to-b from-gray-900 to-black border-b-2 border-green-500/30 relative overflow-hidden">
      <div className="relative z-10 p-4">
        <div className="max-w-full mx-auto">
          {/* Main header */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <h1 className="text-2xl lg:text-3xl font-bold text-green-400 terminal-font">
                Nuclear Blast Simulator
              </h1>
              <div className="hidden lg:block">
                <p className="text-green-300 text-sm">Interactive blast effects calculator</p>
              </div>
            </div>
            
            {/* Navigation */}
            <nav className="hidden md:flex items-center gap-2">
              <Link href="/" className="px-4 py-2 text-sm text-green-400 hover:bg-green-400/10 rounded transition">
                Simulator
              </Link>
              <Link href="/methodology" className="px-4 py-2 text-sm text-green-400 hover:bg-green-400/10 rounded transition">
                Methodology
              </Link>
              <Link href="/examples" className="px-4 py-2 text-sm text-green-400 hover:bg-green-400/10 rounded transition">
                Examples
              </Link>
              <Link href="/how-it-works" className="px-4 py-2 text-sm text-green-400 hover:bg-green-400/10 rounded transition">
                How It Works
              </Link>
            </nav>
          </div>
          
        </div>
      </div>
    </header>
  )
}