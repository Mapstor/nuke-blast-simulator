'use client'

import { useSimulatorStore } from '@/store/simulatorStore'

export function ComparisonToggle() {
  const { comparisonMode, setComparisonMode } = useSimulatorStore()

  return (
    <div className="flex items-center justify-between p-4 bg-black/50 border border-green-500/30 rounded">
      <label className="text-sm font-semibold text-green-400">
        Compare Two Weapons
      </label>
      <button
        onClick={() => setComparisonMode(!comparisonMode)}
        className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors border ${
          comparisonMode ? 'bg-green-500/30 border-green-400' : 'bg-black border-green-500/30'
        }`}
      >
        <span
          className={`inline-block h-4 w-4 transform rounded-full transition-transform ${
            comparisonMode ? 'translate-x-6 bg-green-400' : 'translate-x-1 bg-green-500/50'
          }`}
        />
      </button>
    </div>
  )
}