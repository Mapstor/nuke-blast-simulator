'use client'

import { useSimulatorStore } from '@/store/simulatorStore'
import { formatNumber, formatDistance } from '@/lib/utils/format'
import { AnimatedNumber } from './AnimatedNumber'

export function ResultsPanel() {
  const { results, animationPhase, isAnimating } = useSimulatorStore()
  
  if (!results) {
    return (
      <div className="p-6 text-center text-green-400/50">
        <div className="text-sm">Select a weapon and click on the map to see blast effects</div>
      </div>
    )
  }
  
  // Show immediately when results are available, with animation
  const showResults = results && (isAnimating || !isAnimating)
  
  return (
    <div className="p-6 space-y-6">
      {/* Total casualties - shows immediately with counting animation */}
      {showResults && (
        <div className="border border-red-500/50 bg-black/50 p-4 rounded animate-fadeIn">
          <h3 className="font-bold text-sm text-red-400 mb-2">Estimated Casualties</h3>
          <p className="text-3xl text-red-400 font-bold">
            {isAnimating ? (
              <AnimatedNumber 
                value={results.totalCasualties} 
                duration={3000}
                formatFn={formatNumber}
              />
            ) : (
              formatNumber(results.totalCasualties)
            )}
          </p>
          <p className="text-xs text-red-300">Immediate deaths</p>
        </div>
      )}
      
      <div className="space-y-4">
        {/* Show all stats immediately with staggered animation */}
        {showResults && (
          <>
            {/* Fireball */}
            <div className={`border-l-4 border-red-500 pl-4 bg-black/30 py-2 ${isAnimating ? 'animate-slideIn' : ''}`}
                 style={{ animationDelay: isAnimating ? '0.4s' : '0s' }}>
              <h4 className="font-semibold text-sm text-red-400">Fireball</h4>
              <p className="text-xs text-red-300">Complete vaporization</p>
              <p className="text-xs text-green-400">Radius: {formatDistance(results.fireball.radius)}</p>
              <p className="text-xs text-green-400">
                Deaths: {isAnimating ? (
                  <AnimatedNumber 
                    value={results.fireball.casualties} 
                    duration={1500}
                    formatFn={formatNumber}
                  />
                ) : formatNumber(results.fireball.casualties)}
              </p>
            </div>
        
            {/* Heavy Blast */}
            <div className={`border-l-4 border-orange-500 pl-4 bg-black/30 py-2 ${isAnimating ? 'animate-slideIn' : ''}`}
                 style={{ animationDelay: isAnimating ? '0.6s' : '0s' }}>
              <h4 className="font-semibold text-sm text-orange-400">Heavy Blast (20 PSI)</h4>
              <p className="text-xs text-orange-300">Concrete buildings destroyed</p>
              <p className="text-xs text-green-400">Radius: {formatDistance(results.airBlast.severe.radius)}</p>
              <p className="text-xs text-green-400">
                Deaths: {isAnimating ? (
                  <AnimatedNumber 
                    value={results.airBlast.severe.casualties} 
                    duration={1500}
                    formatFn={formatNumber}
                  />
                ) : formatNumber(results.airBlast.severe.casualties)}
              </p>
            </div>
        
            {/* Moderate Blast */}
            <div className={`border-l-4 border-orange-400 pl-4 bg-black/30 py-2 ${isAnimating ? 'animate-slideIn' : ''}`}
                 style={{ animationDelay: isAnimating ? '0.8s' : '0s' }}>
              <h4 className="font-semibold text-sm text-orange-400">Moderate Blast (5 PSI)</h4>
              <p className="text-xs text-orange-300">Most buildings collapse</p>
              <p className="text-xs text-green-400">Radius: {formatDistance(results.airBlast.moderate.radius)}</p>
              <p className="text-xs text-green-400">
                Casualties: {isAnimating ? (
                  <AnimatedNumber 
                    value={results.airBlast.moderate.casualties} 
                    duration={1500}
                    formatFn={formatNumber}
                  />
                ) : formatNumber(results.airBlast.moderate.casualties)}
              </p>
            </div>
        
            {/* Light Blast */}
            <div className={`border-l-4 border-yellow-500 pl-4 bg-black/30 py-2 ${isAnimating ? 'animate-slideIn' : ''}`}
                 style={{ animationDelay: isAnimating ? '1.0s' : '0s' }}>
              <h4 className="font-semibold text-sm text-yellow-400">Light Blast (1 PSI)</h4>
              <p className="text-xs text-yellow-300">Windows shatter</p>
              <p className="text-xs text-green-400">Radius: {formatDistance(results.airBlast.light.radius)}</p>
              <p className="text-xs text-green-400">
                Injuries: {isAnimating ? (
                  <AnimatedNumber 
                    value={results.airBlast.light.casualties} 
                    duration={1500}
                    formatFn={formatNumber}
                  />
                ) : formatNumber(results.airBlast.light.casualties)}
              </p>
            </div>
        
            {/* Thermal Radiation */}
            <div className={`border-l-4 border-purple-500 pl-4 bg-black/30 py-2 ${isAnimating ? 'animate-slideIn' : ''}`}
                 style={{ animationDelay: isAnimating ? '1.2s' : '0s' }}>
              <h4 className="font-semibold text-sm text-purple-400">Thermal Radiation</h4>
              <p className="text-xs text-purple-300">3rd degree burns</p>
              <p className="text-xs text-green-400">Radius: {formatDistance(results.thermalRadiation.thirdDegree.radius)}</p>
              <p className="text-xs text-green-400">
                Severe burns: {isAnimating ? (
                  <AnimatedNumber 
                    value={results.thermalRadiation.thirdDegree.casualties} 
                    duration={1500}
                    formatFn={formatNumber}
                  />
                ) : formatNumber(results.thermalRadiation.thirdDegree.casualties)}
              </p>
            </div>
        
            {/* Radioactive Fallout */}
            {results.fallout && (
              <div className={`border-l-4 border-green-500 pl-4 bg-black/30 py-2 ${isAnimating ? 'animate-slideIn' : ''}`}
                   style={{ animationDelay: isAnimating ? '1.4s' : '0s' }}>
                <h4 className="font-semibold text-sm text-green-400">Radioactive Fallout</h4>
                <p className="text-xs text-green-300">Lethal radiation (48hr)</p>
                <p className="text-xs text-green-400">Radius: {formatDistance(results.fallout.radius)}</p>
                <p className="text-xs text-green-400">
                  At risk: {isAnimating ? (
                    <AnimatedNumber 
                      value={results.fallout.affectedPopulation} 
                      duration={1500}
                      formatFn={formatNumber}
                    />
                  ) : formatNumber(results.fallout.affectedPopulation)}
                </p>
              </div>
            )}
          </>
        )}
      </div>
      
      <div className="text-xs text-green-400/50 pt-4 border-t border-green-500/30">
        <p>Estimates based on average urban density</p>
        <p>Actual casualties depend on many factors</p>
      </div>
    </div>
  )
}