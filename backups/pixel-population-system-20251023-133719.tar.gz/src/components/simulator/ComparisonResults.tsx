'use client'

import { useSimulatorStore } from '@/store/simulatorStore'
import { formatNumber, formatDistance, formatYield } from '@/lib/utils/format'

export function ComparisonResults() {
  const { 
    comparisonMode, 
    selectedBomb, 
    comparisonBomb, 
    results, 
    comparisonResults 
  } = useSimulatorStore()

  if (!comparisonMode || !selectedBomb || !comparisonBomb || !results || !comparisonResults) {
    return null
  }

  const compareValue = (value1: number, value2: number) => {
    const diff = value1 - value2
    const percent = ((value1 / value2 - 1) * 100).toFixed(0)
    if (diff > 0) return `+${percent}%`
    return `${percent}%`
  }

  return (
    <div className="p-6 bg-black border-t border-green-500/30">
      <h3 className="font-bold text-sm text-green-400 mb-4">Weapon Comparison</h3>
      
      <div className="space-y-4">
        {/* Weapon info */}
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-black/50 p-3 rounded border border-red-500/50">
            <p className="font-semibold text-xs text-red-400">Weapon 1</p>
            <p className="text-xs text-red-300">{selectedBomb.name}</p>
            <p className="text-xs text-red-300/70">{formatYield(selectedBomb.yield)}</p>
          </div>
          <div className="bg-black/50 p-3 rounded border border-green-500/50">
            <p className="font-semibold text-xs text-green-400">Weapon 2</p>
            <p className="text-xs text-green-300">{comparisonBomb.name}</p>
            <p className="text-xs text-green-300/70">{formatYield(comparisonBomb.yield)}</p>
          </div>
        </div>

        {/* Comparison metrics */}
        <div className="bg-black/50 border border-green-500/30 rounded p-4">
          <h4 className="font-semibold text-xs text-green-400 mb-3">Blast Radius Comparison</h4>
          
          <div className="space-y-2 text-xs">
            <div className="flex justify-between items-center">
              <span className="text-green-400/70">Fireball</span>
              <div className="flex gap-2">
                <span className="text-red-400">{formatDistance(results.fireball.radius)}</span>
                <span className="text-green-400/50">vs</span>
                <span className="text-green-400">{formatDistance(comparisonResults.fireball.radius)}</span>
                <span className="font-bold text-yellow-400">{compareValue(results.fireball.radius, comparisonResults.fireball.radius)}</span>
              </div>
            </div>
            
            <div className="flex justify-between items-center">
              <span className="text-green-400/70">Heavy Blast</span>
              <div className="flex gap-2">
                <span className="text-red-400">{formatDistance(results.airBlast.severe.radius)}</span>
                <span className="text-green-400/50">vs</span>
                <span className="text-green-400">{formatDistance(comparisonResults.airBlast.severe.radius)}</span>
                <span className="font-bold text-yellow-400">{compareValue(results.airBlast.severe.radius, comparisonResults.airBlast.severe.radius)}</span>
              </div>
            </div>
            
            <div className="flex justify-between items-center">
              <span className="text-green-400/70">Moderate Blast</span>
              <div className="flex gap-2">
                <span className="text-red-400">{formatDistance(results.airBlast.moderate.radius)}</span>
                <span className="text-green-400/50">vs</span>
                <span className="text-green-400">{formatDistance(comparisonResults.airBlast.moderate.radius)}</span>
                <span className="font-bold text-yellow-400">{compareValue(results.airBlast.moderate.radius, comparisonResults.airBlast.moderate.radius)}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Casualties comparison */}
        <div className="bg-black/50 border border-red-500/30 rounded p-4">
          <h4 className="font-semibold text-xs text-red-400 mb-3">Estimated Casualties</h4>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-red-400 text-xl font-bold">{formatNumber(results.totalCasualties)}</p>
              <p className="text-xs text-red-300/70">{selectedBomb.name}</p>
            </div>
            <div>
              <p className="text-green-400 text-xl font-bold">{formatNumber(comparisonResults.totalCasualties)}</p>
              <p className="text-xs text-green-300/70">{comparisonBomb.name}</p>
            </div>
          </div>
          
          <div className="mt-2 text-center border-t border-red-500/30 pt-2">
            <p className="text-xs font-semibold text-yellow-400">
              Difference: {formatNumber(Math.abs(results.totalCasualties - comparisonResults.totalCasualties))}
            </p>
            <p className="text-xs text-yellow-400/70">
              ({compareValue(results.totalCasualties, comparisonResults.totalCasualties)})
            </p>
          </div>
        </div>

        <div className="text-xs text-green-400/50">
          <p>Red circles = Weapon 1 (solid lines)</p>
          <p>Green circles = Weapon 2 (dashed lines)</p>
        </div>
      </div>
    </div>
  )
}