'use client'

import { useState } from 'react'
import { useSimulatorStore } from '@/store/simulatorStore'
import { presetLocations } from '@/lib/data/cities'

export function LocationSearch({ onLocationSelect }: { onLocationSelect?: (lat: number, lng: number) => void }) {
  const [searchQuery, setSearchQuery] = useState('')
  const [isSearching, setIsSearching] = useState(false)
  const setDetonationPoint = useSimulatorStore(state => state.setDetonationPoint)

  const handleSearch = async () => {
    if (!searchQuery.trim()) return
    
    setIsSearching(true)
    try {
      const response = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(searchQuery)}&limit=1`
      )
      const data = await response.json()
      
      if (data && data[0]) {
        const lat = parseFloat(data[0].lat)
        const lng = parseFloat(data[0].lon)
        setDetonationPoint({ lat, lng })
        if (onLocationSelect) {
          onLocationSelect(lat, lng)
        }
      } else {
        alert('Location not found. Please try another search.')
      }
    } catch (error) {
      console.error('Search error:', error)
      alert('Search failed. Please try again.')
    } finally {
      setIsSearching(false)
    }
  }

  const handlePresetSelect = (location: typeof presetLocations[0]) => {
    setDetonationPoint({ lat: location.lat, lng: location.lng })
    if (onLocationSelect) {
      onLocationSelect(location.lat, location.lng)
    }
  }

  return (
    <div className="space-y-4">
      <div>
        <label className="block text-sm font-semibold text-green-400 mb-2">Search Location</label>
        <div className="flex gap-2">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
            placeholder="Enter city or location..."
            className="flex-1 p-2 bg-black border border-green-500/50 text-green-400 rounded placeholder-green-400/30 focus:border-green-400 focus:outline-none"
            disabled={isSearching}
          />
          <button
            onClick={handleSearch}
            disabled={isSearching}
            className="px-4 py-2 bg-green-500/20 text-green-400 border border-green-500/50 rounded hover:bg-green-500/30 transition"
          >
            {isSearching ? 'Searching...' : 'Search'}
          </button>
        </div>
      </div>

      <div>
        <label className="block text-sm font-semibold text-green-400 mb-2">Quick Select Cities</label>
        <div className="grid grid-cols-2 gap-2">
          {presetLocations.map((location) => (
            <button
              key={location.name}
              onClick={() => handlePresetSelect(location)}
              className="p-2 text-sm bg-black/50 border border-green-500/30 text-green-400 hover:bg-green-500/10 hover:border-green-400 rounded transition"
            >
              {location.name}
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}