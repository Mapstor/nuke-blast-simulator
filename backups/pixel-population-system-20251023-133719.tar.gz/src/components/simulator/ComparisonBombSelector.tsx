'use client'

import { bombs } from '@/lib/data/bombs'
import { useSimulatorStore } from '@/store/simulatorStore'

export function ComparisonBombSelector() {
  const { comparisonMode, comparisonBomb, setComparisonBomb } = useSimulatorStore()

  if (!comparisonMode) return null

  return (
    <div className="space-y-4 p-4 bg-black border border-green-400/50 rounded">
      <label className="block text-sm font-semibold text-green-400">
        Weapon 2 (Comparison)
      </label>
      <select
        className="w-full p-2 bg-black border border-green-500/50 text-green-400 rounded focus:border-green-400 focus:outline-none"
        onChange={(e) => {
          const bomb = bombs.find(b => b.id === e.target.value)
          if (bomb) setComparisonBomb(bomb)
        }}
        value={comparisonBomb?.id || ''}
      >
        <option value="">Choose second weapon...</option>
        {bombs.map(bomb => (
          <option key={bomb.id} value={bomb.id}>
            {bomb.name} ({bomb.yield.toLocaleString()} kt)
          </option>
        ))}
      </select>
      
      {comparisonBomb && (
        <div className="p-3 bg-black/50 border border-green-500/30 rounded">
          <p className="text-sm text-green-300">{comparisonBomb.description}</p>
          <p className="text-xs text-green-400/70 mt-2">
            {comparisonBomb.country} • {comparisonBomb.year}
          </p>
        </div>
      )}
    </div>
  )
}