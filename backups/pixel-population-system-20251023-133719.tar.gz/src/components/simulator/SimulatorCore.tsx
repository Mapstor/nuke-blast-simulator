'use client'

import { useEffect } from 'react'
import { useSimulatorStore } from '@/store/simulatorStore'
import { calculateFireball, calculateAirBlast, calculateThermalRadiation, calculateFallout } from '@/lib/calculations/blast'
import { calculateNuclearCasualties } from '@/lib/calculations/casualties'
import { DEFAULT_URBAN_DENSITY } from '@/lib/data/cities'
import { getPopulationDensity } from '@/lib/services/populationGrid'
import { BlastResults, EffectZone } from '@/lib/types'
import { Bomb } from '@/lib/types'

function calculateBlastEffects(
  bomb: Bomb, 
  detonationPoint: { lat: number; lng: number }, 
  customYield: number, 
  burstType: 'air' | 'surface' = 'air',
  populationDensity: number = DEFAULT_URBAN_DENSITY
): BlastResults {
  const yieldKt = bomb.id === 'custom' ? customYield : bomb.yield
  
  // Use new pixel-based calculation system
  const casualtyZones = calculateNuclearCasualties(
    detonationPoint.lat,
    detonationPoint.lng,
    yieldKt,
    burstType
  )
  
  // Map zones to our result structure
  const fireballZone = casualtyZones.find(z => z.name === 'Fireball')
  const severeZone = casualtyZones.find(z => z.name === 'Severe blast damage')  
  const moderateZone = casualtyZones.find(z => z.name === 'Moderate blast damage')
  const lightZone = casualtyZones.find(z => z.name === 'Light blast damage')
  const thermal3rdZone = casualtyZones.find(z => z.name === '3rd degree burns')
  const thermal2ndZone = casualtyZones.find(z => z.name === '2nd degree burns')
  const falloutZone = casualtyZones.find(z => z.name === 'Fallout (lethal)')
  
  // Helper to create EffectZone
  const createZone = (zone: any): EffectZone => ({
    radius: zone?.radius || 0,
    casualties: zone?.casualties || 0,
    fatalities: zone?.fatalities || 0,
    survivorsWithInjuries: zone?.survivorsWithInjuries || 0,
    totalPopulation: zone?.totalPopulation || 0,
    averageDensity: zone?.averageDensity || 0
  })
  
  // Calculate totals
  const totalCasualties = casualtyZones.reduce((sum, zone) => sum + zone.casualties, 0)
  const totalFatalities = casualtyZones.reduce((sum, zone) => sum + zone.fatalities, 0)
  const totalSurvivorsWithInjuries = casualtyZones.reduce((sum, zone) => sum + zone.survivorsWithInjuries, 0)
  const affectedPopulation = casualtyZones.reduce((sum, zone) => sum + zone.totalPopulation, 0)
  
  const results: BlastResults = {
    fireball: {
      radius: fireballZone?.radius || 0,
      casualties: fireballZone?.casualties || 0,
      fatalities: fireballZone?.fatalities || 0,
      survivorsWithInjuries: fireballZone?.survivorsWithInjuries || 0,
      totalPopulation: fireballZone?.totalPopulation || 0,
      averageDensity: fireballZone?.averageDensity || 0,
      description: 'Complete vaporization zone'
    },
    airBlast: {
      severe: createZone(severeZone),
      moderate: createZone(moderateZone),
      light: createZone(lightZone)
    },
    thermalRadiation: {
      thirdDegree: createZone(thermal3rdZone),
      secondDegree: createZone(thermal2ndZone)
    },
    totalCasualties,
    totalFatalities,
    totalSurvivorsWithInjuries,
    affectedPopulation,
    casualtyZones
  }
  
  // Add fallout if surface burst
  if (falloutZone) {
    results.fallout = {
      radius: falloutZone.radius,
      casualties: falloutZone.casualties,
      fatalities: falloutZone.fatalities,
      survivorsWithInjuries: falloutZone.survivorsWithInjuries,
      totalPopulation: falloutZone.totalPopulation,
      averageDensity: falloutZone.averageDensity,
      affectedPopulation: falloutZone.totalPopulation
    }
  }
  
  return results
}

export function SimulatorCore() {
  const { 
    selectedBomb, 
    detonationPoint, 
    customYield,
    burstType,
    populationData,
    setResults,
    setPopulationData,
    comparisonBomb,
    setComparisonResults 
  } = useSimulatorStore()
  
  // Fetch population data when detonation point changes
  useEffect(() => {
    if (!detonationPoint) {
      setPopulationData(null)
      return
    }
    
    // Get population density for the location
    getPopulationDensity(detonationPoint.lat, detonationPoint.lng)
      .then(data => {
        setPopulationData(data)
      })
      .catch(error => {
        console.error('Failed to fetch population data:', error)
        // Fallback to safe default
        setPopulationData({
          cityName: 'Unknown location',
          population: 0,
          density: 100,
          country: 'Unknown',
          distance: 0,
          isUrban: false
        })
      })
  }, [detonationPoint, setPopulationData])
  
  // Calculate blast effects when inputs change
  useEffect(() => {
    if (!selectedBomb || !detonationPoint) {
      setResults(null)
      return
    }
    
    // Use population density if available, otherwise use default
    const density = populationData?.density !== undefined ? populationData.density : DEFAULT_URBAN_DENSITY
    const results = calculateBlastEffects(selectedBomb, detonationPoint, customYield, burstType, density)
    setResults(results)
  }, [selectedBomb, detonationPoint, customYield, burstType, populationData, setResults])
  
  // Handle comparison bomb calculations
  useEffect(() => {
    if (!comparisonBomb || !detonationPoint) {
      setComparisonResults(null)
      return
    }
    
    const density = populationData?.density !== undefined ? populationData.density : DEFAULT_URBAN_DENSITY
    const results = calculateBlastEffects(comparisonBomb, detonationPoint, customYield, burstType, density)
    setComparisonResults(results)
  }, [comparisonBomb, detonationPoint, customYield, burstType, populationData, setComparisonResults])
  
  return null
}