'use client'

import { useEffect, useState } from 'react'

interface ExplosionAnimationProps {
  lat: number
  lng: number
  onComplete?: () => void
}

export function ExplosionAnimation({ lat, lng, onComplete }: ExplosionAnimationProps) {
  const [phase, setPhase] = useState<'flash' | 'fireball' | 'mushroom' | 'complete'>('flash')
  
  useEffect(() => {
    const timers: NodeJS.Timeout[] = []
    
    // Flash phase (instant white flash)
    timers.push(setTimeout(() => setPhase('fireball'), 200))
    
    // Fireball expansion
    timers.push(setTimeout(() => setPhase('mushroom'), 800))
    
    // Mushroom cloud formation
    timers.push(setTimeout(() => {
      setPhase('complete')
      onComplete?.()
    }, 3000))
    
    return () => {
      timers.forEach(timer => clearTimeout(timer))
    }
  }, [onComplete])
  
  if (phase === 'complete') return null
  
  return (
    <div className="explosion-container">
      {/* White flash */}
      {phase === 'flash' && (
        <div className="explosion-flash" />
      )}
      
      {/* Fireball */}
      {(phase === 'fireball' || phase === 'mushroom') && (
        <div className="explosion-fireball" />
      )}
      
      {/* Shockwave ring */}
      {(phase === 'fireball' || phase === 'mushroom') && (
        <div className="explosion-shockwave" />
      )}
      
      {/* Mushroom cloud */}
      {phase === 'mushroom' && (
        <>
          <div className="mushroom-stem" />
          <div className="mushroom-cap" />
          <div className="mushroom-ring" />
        </>
      )}
    </div>
  )
}