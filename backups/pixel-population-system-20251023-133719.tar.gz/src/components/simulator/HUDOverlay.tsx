'use client'

import { useSimulatorStore } from '@/store/simulatorStore'
import { formatNumber, formatDistance } from '@/lib/utils/format'
import { getPopulationContext } from '@/lib/services/populationGrid'

export function HUDOverlay() {
  const { detonationPoint, selectedBomb, results, burstType, populationData } = useSimulatorStore()

  return (
    <div className="absolute inset-0 pointer-events-none z-20">
      {/* Simple crosshair */}
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
        <svg width="60" height="60" className="text-green-400 opacity-20">
          <line x1="30" y1="0" x2="30" y2="60" stroke="currentColor" strokeWidth="1" />
          <line x1="0" y1="30" x2="60" y2="30" stroke="currentColor" strokeWidth="1" />
          <circle cx="30" cy="30" r="20" fill="none" stroke="currentColor" strokeWidth="1" strokeDasharray="3,3" />
        </svg>
      </div>

      {/* Top left - Coordinates */}
      <div className="absolute top-4 left-4 bg-black/80 border border-green-400/30 p-3 text-xs rounded">
        <div className="text-green-400 mb-1 font-semibold">Target Location</div>
        {detonationPoint ? (
          <>
            <div className="text-green-300">Lat: {detonationPoint.lat.toFixed(4)}°</div>
            <div className="text-green-300">Lng: {detonationPoint.lng.toFixed(4)}°</div>
          </>
        ) : (
          <div className="text-green-300/50">Click map to select</div>
        )}
      </div>

      {/* Top right - Weapon Status */}
      <div className="absolute top-4 right-4 bg-black/80 border border-green-400/30 p-3 text-xs rounded">
        <div className="text-green-400 mb-1 font-semibold">Selected Weapon</div>
        {selectedBomb ? (
          <>
            <div className="text-green-300">{selectedBomb.name}</div>
            <div className="text-green-300">Yield: {selectedBomb.yield} kt</div>
            <div className="text-green-300">Type: {selectedBomb.type}</div>
            <div className="text-yellow-300">Burst: {burstType === 'air' ? 'Air' : 'Surface'}</div>
          </>
        ) : (
          <div className="text-green-300/50">No weapon selected</div>
        )}
      </div>

      {/* Bottom left - Impact Assessment */}
      {results && (
        <div className="absolute bottom-4 left-4 bg-black/80 border border-red-400/30 p-3 text-xs rounded">
          <div className="text-red-400 mb-1 font-semibold">Impact Summary</div>
          <div className="text-red-300">Casualties: {formatNumber(results.totalCasualties)}</div>
          <div className="text-orange-300">Fireball: {formatDistance(results.fireball.radius)}</div>
          <div className="text-orange-300">Blast zone: {formatDistance(results.airBlast.moderate.radius)}</div>
          <div className="text-yellow-300">Thermal burns: {formatDistance(results.thermalRadiation.thirdDegree.radius)}</div>
        </div>
      )}

      {/* Bottom right - Location Context */}
      {detonationPoint && populationData && (
        <div className="absolute bottom-4 right-4 bg-black/80 border border-blue-400/30 p-3 text-xs rounded">
          <div className="text-blue-400 mb-1 font-semibold">Location Context</div>
          <div className="text-blue-300">{getPopulationContext(populationData)}</div>
          <div className="text-blue-300">Density: {formatNumber(populationData.density)}/km²</div>
          <div className="text-blue-300">Country: {populationData.country}</div>
        </div>
      )}



    </div>
  )
}