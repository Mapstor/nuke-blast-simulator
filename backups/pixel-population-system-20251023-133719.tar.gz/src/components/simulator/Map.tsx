'use client'

import { useEffect, useRef, useState } from 'react'
import { MapContainer, TileLayer, Circle, Marker, useMapEvents, useMap } from 'react-leaflet'
import { useSimulatorStore } from '@/store/simulatorStore'
import { MapControls } from './MapControls'
import 'leaflet/dist/leaflet.css'
import L from 'leaflet'

// Fix for default markers in Next.js
if (typeof window !== 'undefined') {
  delete (L.Icon.Default.prototype as any)._getIconUrl
  L.Icon.Default.mergeOptions({
    iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
    iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
    shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
  })
}

function MapClickHandler() {
  const setDetonationPoint = useSimulatorStore(state => state.setDetonationPoint)
  const startExplosionSequence = useSimulatorStore(state => state.startExplosionSequence)
  
  useMapEvents({
    click: (e) => {
      // Set the detonation point slightly delayed to sync with explosion
      setTimeout(() => {
        setDetonationPoint({ lat: e.latlng.lat, lng: e.latlng.lng })
      }, 200)
    }
  })
  
  return null
}

export function Map() {
  const detonationPoint = useSimulatorStore(state => state.detonationPoint)
  const results = useSimulatorStore(state => state.results)
  const comparisonMode = useSimulatorStore(state => state.comparisonMode)
  const comparisonResults = useSimulatorStore(state => state.comparisonResults)
  const animationPhase = useSimulatorStore(state => state.animationPhase)
  const isAnimating = useSimulatorStore(state => state.isAnimating)
  const [mapKey, setMapKey] = useState(0)
  const containerRef = useRef<HTMLDivElement>(null)
  
  useEffect(() => {
    // Force a new map instance on mount to avoid container issues
    setMapKey(prev => prev + 1)
    
    return () => {
      // Clean up the map container on unmount
      if (containerRef.current) {
        containerRef.current.innerHTML = ''
      }
    }
  }, [])
  
  return (
    <div ref={containerRef} style={{ height: '100%', width: '100%' }}>
      <MapContainer
        key={`map-${mapKey}`}
        center={[40.7128, -74.0060]}
        zoom={10}
        style={{ height: '100%', width: '100%' }}
        className="z-0"
      >
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        />
        <MapClickHandler />
        <MapControls />
        
        {detonationPoint && (
          <Marker position={[detonationPoint.lat, detonationPoint.lng]} />
        )}
        
        {results && detonationPoint && (
          <>
            {/* Fireball - shows immediately after explosion */}
            {(animationPhase === 'showing-fireball' || 
              animationPhase === 'showing-heavy-blast' ||
              animationPhase === 'showing-moderate-blast' ||
              animationPhase === 'showing-light-blast' ||
              animationPhase === 'showing-thermal' ||
              animationPhase === 'showing-fallout' ||
              animationPhase === 'complete') && (
              <Circle
                center={[detonationPoint.lat, detonationPoint.lng]}
                radius={results.fireball.radius * 1000}
                pathOptions={{ 
                  color: '#ff0000', 
                  fillColor: '#ff0000', 
                  fillOpacity: 0.5,
                  className: isAnimating ? 'blast-zone-animate' : ''
                }}
              />
            )}
            
            {/* Heavy Blast (20 PSI) */}
            {(animationPhase === 'showing-heavy-blast' ||
              animationPhase === 'showing-moderate-blast' ||
              animationPhase === 'showing-light-blast' ||
              animationPhase === 'showing-thermal' ||
              animationPhase === 'showing-fallout' ||
              animationPhase === 'complete') && (
              <Circle
                center={[detonationPoint.lat, detonationPoint.lng]}
                radius={results.airBlast.severe.radius * 1000}
                pathOptions={{ 
                  color: '#ff3300', 
                  fillColor: '#ff3300', 
                  fillOpacity: 0.2,
                  className: isAnimating ? 'blast-zone-animate' : ''
                }}
              />
            )}
            
            {/* Moderate Blast (5 PSI) */}
            {(animationPhase === 'showing-moderate-blast' ||
              animationPhase === 'showing-light-blast' ||
              animationPhase === 'showing-thermal' ||
              animationPhase === 'showing-fallout' ||
              animationPhase === 'complete') && (
              <Circle
                center={[detonationPoint.lat, detonationPoint.lng]}
                radius={results.airBlast.moderate.radius * 1000}
                pathOptions={{ 
                  color: '#ff6600', 
                  fillColor: '#ff6600', 
                  fillOpacity: 0.15,
                  className: isAnimating ? 'blast-zone-animate' : ''
                }}
              />
            )}
            
            {/* Light Blast (1 PSI) */}
            {(animationPhase === 'showing-light-blast' ||
              animationPhase === 'showing-thermal' ||
              animationPhase === 'showing-fallout' ||
              animationPhase === 'complete') && (
              <Circle
                center={[detonationPoint.lat, detonationPoint.lng]}
                radius={results.airBlast.light.radius * 1000}
                pathOptions={{ 
                  color: '#ffcc00', 
                  fillColor: '#ffcc00', 
                  fillOpacity: 0.1,
                  className: isAnimating ? 'blast-zone-animate' : ''
                }}
              />
            )}
            
            {/* Thermal Radiation Zones */}
            {(animationPhase === 'showing-thermal' ||
              animationPhase === 'showing-fallout' ||
              animationPhase === 'complete') && (
              <>
                <Circle
                  center={[detonationPoint.lat, detonationPoint.lng]}
                  radius={results.thermalRadiation.thirdDegree.radius * 1000}
                  pathOptions={{ 
                    color: '#cc00cc', 
                    fillColor: '#cc00cc', 
                    fillOpacity: 0.15,
                    className: isAnimating ? 'blast-zone-animate' : ''
                  }}
                />
                <Circle
                  center={[detonationPoint.lat, detonationPoint.lng]}
                  radius={results.thermalRadiation.secondDegree.radius * 1000}
                  pathOptions={{ 
                    color: '#ff00ff', 
                    fillColor: '#ff00ff', 
                    fillOpacity: 0.1,
                    className: isAnimating ? 'blast-zone-animate' : ''
                  }}
                />
              </>
            )}
          </>
        )}
        
        {/* Comparison circles */}
        {comparisonMode && comparisonResults && detonationPoint && (
          <>
            <Circle
              center={[detonationPoint.lat, detonationPoint.lng]}
              radius={comparisonResults.fireball.radius * 1000}
              pathOptions={{ color: '#00ff00', fillColor: '#00ff00', fillOpacity: 0.3, dashArray: '5, 5' }}
            />
            <Circle
              center={[detonationPoint.lat, detonationPoint.lng]}
              radius={comparisonResults.airBlast.moderate.radius * 1000}
              pathOptions={{ color: '#00cc00', fillColor: '#00cc00', fillOpacity: 0.15, dashArray: '5, 5' }}
            />
            <Circle
              center={[detonationPoint.lat, detonationPoint.lng]}
              radius={comparisonResults.airBlast.light.radius * 1000}
              pathOptions={{ color: '#009900', fillColor: '#009900', fillOpacity: 0.1, dashArray: '5, 5' }}
            />
          </>
        )}
      </MapContainer>
    </div>
  )
}