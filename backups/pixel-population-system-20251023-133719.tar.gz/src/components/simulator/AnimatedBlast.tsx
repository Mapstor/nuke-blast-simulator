'use client'

import { motion } from 'framer-motion'
import { Circle } from 'react-leaflet'
import { useSimulatorStore } from '@/store/simulatorStore'

export function AnimatedBlast() {
  const { detonationPoint, results } = useSimulatorStore()

  if (!results || !detonationPoint) return null

  return (
    <>
      {/* Animated expanding circles using CSS */}
      <Circle
        center={[detonationPoint.lat, detonationPoint.lng]}
        radius={results.fireball.radius * 1000}
        pathOptions={{ 
          color: '#ff0000', 
          fillColor: '#ff0000', 
          fillOpacity: 0.5,
          className: 'blast-animation-fireball'
        }}
      />
      
      <Circle
        center={[detonationPoint.lat, detonationPoint.lng]}
        radius={results.airBlast.severe.radius * 1000}
        pathOptions={{ 
          color: '#ff3300', 
          fillColor: '#ff3300', 
          fillOpacity: 0.2,
          className: 'blast-animation-severe'
        }}
      />
      
      <Circle
        center={[detonationPoint.lat, detonationPoint.lng]}
        radius={results.airBlast.moderate.radius * 1000}
        pathOptions={{ 
          color: '#ff6600', 
          fillColor: '#ff6600', 
          fillOpacity: 0.15,
          className: 'blast-animation-moderate'
        }}
      />
      
      <Circle
        center={[detonationPoint.lat, detonationPoint.lng]}
        radius={results.airBlast.light.radius * 1000}
        pathOptions={{ 
          color: '#ffcc00', 
          fillColor: '#ffcc00', 
          fillOpacity: 0.1,
          className: 'blast-animation-light'
        }}
      />
    </>
  )
}