'use client'

import { useEffect, useState, useRef } from 'react'
import dynamic from 'next/dynamic'
import { NuclearExplosion } from './NuclearExplosion'
import { useSimulatorStore } from '@/store/simulatorStore'

const MapComponent = dynamic(
  () => import('./Map').then((mod) => mod.Map),
  { 
    ssr: false,
    loading: () => <div className="h-full w-full bg-gray-200 animate-pulse flex items-center justify-center">
      <div className="text-gray-500">Loading map...</div>
    </div>
  }
)

export function MapWrapper({ mapCenter }: { mapCenter?: [number, number] }) {
  const [isMounted, setIsMounted] = useState(false)
  const [explosion, setExplosion] = useState<{ x: number; y: number } | null>(null)
  const mapContainerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    setIsMounted(true)
    return () => setIsMounted(false)
  }, [])

  if (!isMounted) {
    return <div className="h-full w-full bg-gray-200 animate-pulse flex items-center justify-center">
      <div className="text-gray-500">Loading map...</div>
    </div>
  }

  return (
    <div 
      ref={mapContainerRef}
      className="relative h-full w-full"
      onClick={(e) => {
        // Get click position relative to viewport
        const rect = e.currentTarget.getBoundingClientRect()
        const x = e.clientX
        const y = e.clientY
        
        // Only trigger explosion if we have a selected bomb
        const state = useSimulatorStore.getState()
        const selectedBomb = state.selectedBomb
        const burstType = state.burstType
        if (selectedBomb) {
          // Add drop animation class to bomb cursor
          const bombCursor = document.querySelector('.bomb-cursor')
          if (bombCursor) {
            bombCursor.classList.add('bomb-dropping')
            setTimeout(() => {
              bombCursor.classList.remove('bomb-dropping')
            }, 500)
          }
          
          // Start the explosion sequence in the store
          useSimulatorStore.getState().startExplosionSequence()
          
          // Trigger explosion after drop animation
          setTimeout(() => {
            setExplosion({ x, y })
          }, 300)
        }
      }}
    >
      <MapComponent />
      {explosion && (
        <NuclearExplosion
          key={`explosion-${explosion.x}-${explosion.y}`}
          x={explosion.x}
          y={explosion.y}
          onComplete={() => setExplosion(null)}
        />
      )}
    </div>
  )
}