'use client'

import { useState, useEffect } from 'react'
import { BombSelector } from '@/components/simulator/BombSelector'
import { BurstTypeSelector } from '@/components/simulator/BurstTypeSelector'
import { ResultsPanel } from '@/components/simulator/ResultsPanel'
import { SimulatorCore } from '@/components/simulator/SimulatorCore'
import { MapWrapper } from '@/components/simulator/MapWrapper'
import { LocationSearch } from '@/components/simulator/LocationSearch'
import { ShareButton } from '@/components/simulator/ShareButton'
import { ComparisonToggle } from '@/components/simulator/ComparisonToggle'
import { ComparisonBombSelector } from '@/components/simulator/ComparisonBombSelector'
import { ComparisonResults } from '@/components/simulator/ComparisonResults'
import { HUDOverlay } from '@/components/simulator/HUDOverlay'
import { BombCursor } from '@/components/simulator/BombCursor'
import { PopulationIndicator } from '@/components/simulator/PopulationIndicator'
import { useSimulatorStore } from '@/store/simulatorStore'
import { bombs } from '@/lib/data/bombs'

export default function Home() {
  const { selectedBomb, setSelectedBomb, setDetonationPoint } = useSimulatorStore()
  const [activeTab, setActiveTab] = useState('map')
  
  useEffect(() => {
    // Check for shared parameters in URL
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search)
      const bombId = params.get('bomb')
      const lat = params.get('lat')
      const lng = params.get('lng')
      
      if (bombId && lat && lng) {
        const bomb = bombs.find(b => b.id === bombId)
        if (bomb) {
          setSelectedBomb(bomb)
          setDetonationPoint({ 
            lat: parseFloat(lat), 
            lng: parseFloat(lng) 
          })
        }
      }
    }
  }, [setSelectedBomb, setDetonationPoint])
  
  return (
    <main className={`h-screen flex flex-col bg-black ${selectedBomb ? 'has-weapon-selected' : ''}`}>
      <SimulatorCore />
      <BombCursor />
      
      <div className="flex-1 flex flex-col lg:flex-row overflow-hidden relative">
        {/* Mobile tabs */}
        <div className="lg:hidden bg-black border-b border-green-500/30 flex">
          <button 
            onClick={() => setActiveTab('controls')}
            className={`flex-1 p-3 text-sm font-medium ${activeTab === 'controls' ? 'bg-green-500/20 text-green-400 border-b-2 border-green-400' : 'text-green-400/50'}`}
          >
            Controls
          </button>
          <button 
            onClick={() => setActiveTab('map')}
            className={`flex-1 p-3 text-sm font-medium ${activeTab === 'map' ? 'bg-green-500/20 text-green-400 border-b-2 border-green-400' : 'text-green-400/50'}`}
          >
            Map
          </button>
          <button 
            onClick={() => setActiveTab('results')}
            className={`flex-1 p-3 text-sm font-medium ${activeTab === 'results' ? 'bg-green-500/20 text-green-400 border-b-2 border-green-400' : 'text-green-400/50'}`}
          >
            Results
          </button>
        </div>

        {/* Left Panel - Controls */}
        <aside className={`lg:w-96 bg-gray-900 lg:border-r lg:border-green-500/30 p-4 lg:p-6 overflow-y-auto space-y-6 ${activeTab === 'controls' ? 'block' : 'hidden lg:block'}`}>
          <LocationSearch />
          
          <div className="border-t border-green-500/30 pt-6">
            <BombSelector />
          </div>
          
          <div className="border-t border-green-500/30 pt-6">
            <BurstTypeSelector />
          </div>
          
          <div className="border-t border-green-500/30 pt-6">
            <ComparisonToggle />
          </div>
          
          <ComparisonBombSelector />
          
          <div className="p-4 bg-black border border-green-500/30 rounded">
            <p className="text-sm text-green-400">
              📍 Click anywhere on the map to simulate detonation
            </p>
          </div>
        </aside>
        
        {/* Center - Map */}
        <div className={`flex-1 relative h-96 lg:h-auto ${activeTab === 'map' ? 'block' : 'hidden lg:block'}`}>
          <MapWrapper />
          <HUDOverlay />
          <PopulationIndicator />
        </div>
        
        {/* Right Panel - Results */}
        <aside className={`lg:w-96 bg-gray-900 lg:border-l lg:border-green-500/30 overflow-y-auto ${activeTab === 'results' ? 'block' : 'hidden lg:block'}`}>
          <ResultsPanel />
          <ComparisonResults />
          <div className="p-4 lg:p-6 pt-0">
            <ShareButton />
          </div>
        </aside>
      </div>
    </main>
  )
}