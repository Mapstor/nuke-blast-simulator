import { Metadata } from 'next'
import Link from 'next/link'
import { presetLocations } from '@/lib/data/cities'

export const metadata: Metadata = {
  title: 'Nuclear Blast Examples - Major Cities Worldwide',
  description: 'Explore nuclear blast simulations for major cities worldwide. See the potential impact and learn about nuclear weapons effects.'
}

export default function ExamplesPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-slate-900 text-white p-4">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <Link href="/" className="text-2xl font-bold hover:text-gray-300">
            NukeBlastSimulator.com
          </Link>
          <nav className="flex gap-6">
            <Link href="/" className="hover:text-gray-300">Simulator</Link>
            <Link href="/how-it-works" className="hover:text-gray-300">How It Works</Link>
            <Link href="/methodology" className="hover:text-gray-300">Methodology</Link>
            <Link href="/examples" className="text-gray-300">Examples</Link>
          </nav>
        </div>
      </header>

      <main className="max-w-4xl mx-auto p-8">
        <h1 className="text-4xl font-bold mb-8">City-Specific Nuclear Blast Simulations</h1>
        
        <div className="mb-8 p-4 bg-blue-50 border-l-4 border-blue-400">
          <p className="text-gray-700">
            Select a city below to see detailed analysis of potential nuclear blast effects. 
            These simulations are for educational purposes to understand the humanitarian impact 
            of nuclear weapons.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {presetLocations.map((location) => {
            const slug = location.name?.toLowerCase().replace(/\s+/g, '-')
            return (
              <Link
                key={location.name}
                href={`/examples/${slug}`}
                className="bg-white rounded-lg p-6 shadow-md hover:shadow-lg transition group"
              >
                <h2 className="text-xl font-semibold mb-2 group-hover:text-blue-600">
                  {location.name}
                </h2>
                <div className="text-sm text-gray-600 space-y-1">
                  <p>Population Density: {location.density?.toLocaleString()} per km²</p>
                  <p>Coordinates: {location.lat.toFixed(2)}°, {location.lng.toFixed(2)}°</p>
                </div>
                <div className="mt-4 text-blue-600 font-semibold">
                  View simulation →
                </div>
              </Link>
            )
          })}
        </div>

        <section className="mt-12">
          <h2 className="text-2xl font-semibold mb-4">Why These Cities?</h2>
          <div className="bg-white rounded-lg p-6 shadow-md">
            <p className="text-gray-700 mb-4">
              We've selected major global cities that represent:
            </p>
            <ul className="list-disc list-inside space-y-2 text-gray-700">
              <li>High population density areas</li>
              <li>Major economic and political centers</li>
              <li>Historical Cold War target cities</li>
              <li>Diverse geographic locations worldwide</li>
            </ul>
            <p className="text-gray-700 mt-4">
              Each city page includes specific impact scenarios ranging from tactical nuclear 
              weapons to strategic megaton-class weapons.
            </p>
          </div>
        </section>

        <section className="mt-8">
          <h2 className="text-2xl font-semibold mb-4">Want to Simulate Your Location?</h2>
          <div className="bg-gray-100 rounded-lg p-6">
            <p className="text-gray-700 mb-4">
              Use our interactive simulator to test any location worldwide. You can:
            </p>
            <ul className="list-disc list-inside space-y-2 text-gray-700">
              <li>Search for any city or address</li>
              <li>Choose from 30+ nuclear weapons</li>
              <li>See real-time blast calculations</li>
              <li>Share results with others</li>
            </ul>
            <div className="mt-6">
              <Link 
                href="/"
                className="inline-block bg-blue-600 text-white px-6 py-2 rounded-lg font-semibold hover:bg-blue-700 transition"
              >
                Open Interactive Simulator
              </Link>
            </div>
          </div>
        </section>
      </main>
    </div>
  )
}