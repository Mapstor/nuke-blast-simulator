import { Metadata } from 'next'
import Link from 'next/link'
import { presetLocations } from '@/lib/data/cities'

type Props = {
  params: { city: string }
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const cityName = params.city.replace(/-/g, ' ').replace(/\b\w/g, l => l.toUpperCase())
  
  return {
    title: `Nuclear Blast in ${cityName} - Simulation & Effects`,
    description: `See the devastating effects of a nuclear blast in ${cityName}. Interactive simulation showing blast radius, casualties, and damage zones from various nuclear weapons.`
  }
}

export async function generateStaticParams() {
  return presetLocations.map((location) => ({
    city: location.name?.toLowerCase().replace(/\s+/g, '-')
  }))
}

export default function CityExamplePage({ params }: Props) {
  const citySlug = params.city
  const location = presetLocations.find(
    loc => loc.name?.toLowerCase().replace(/\s+/g, '-') === citySlug
  )
  
  if (!location) {
    return <div>City not found</div>
  }
  
  const simulationUrl = `/?lat=${location.lat}&lng=${location.lng}&bomb=fat-man`
  
  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-slate-900 text-white p-4">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <Link href="/" className="text-2xl font-bold hover:text-gray-300">
            NukeBlastSimulator.com
          </Link>
          <nav className="flex gap-6">
            <Link href="/" className="hover:text-gray-300">Simulator</Link>
            <Link href="/how-it-works" className="hover:text-gray-300">How It Works</Link>
            <Link href="/methodology" className="hover:text-gray-300">Methodology</Link>
          </nav>
        </div>
      </header>

      <main className="max-w-4xl mx-auto p-8">
        <h1 className="text-4xl font-bold mb-4">
          Nuclear Blast Simulation: {location.name}
        </h1>
        
        <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 mb-8">
          <p className="text-gray-700">
            This is an educational simulation showing the hypothetical effects of nuclear weapons.
            The purpose is to promote awareness about nuclear disarmament.
          </p>
        </div>

        <section className="mb-12">
          <h2 className="text-2xl font-semibold mb-4">About {location.name}</h2>
          <div className="bg-white rounded-lg p-6 shadow-md">
            <ul className="space-y-2">
              <li><span className="font-semibold">Location:</span> {location.lat.toFixed(4)}°, {location.lng.toFixed(4)}°</li>
              <li><span className="font-semibold">Population Density:</span> {location.density?.toLocaleString()} per km²</li>
              <li><span className="font-semibold">Urban Area:</span> Major metropolitan center</li>
            </ul>
          </div>
        </section>

        <section className="mb-12">
          <h2 className="text-2xl font-semibold mb-4">Potential Impact Scenarios</h2>
          
          <div className="space-y-6">
            <div className="bg-white rounded-lg p-6 shadow-md">
              <h3 className="text-xl font-semibold mb-2">15 kt (Hiroshima-sized)</h3>
              <p className="text-gray-600 mb-3">Similar to the Little Boy bomb dropped on Hiroshima</p>
              <ul className="space-y-1 text-gray-700">
                <li>• Fireball radius: ~180 meters</li>
                <li>• Heavy blast damage: ~1.2 km radius</li>
                <li>• Moderate damage: ~3.2 km radius</li>
                <li>• Estimated casualties: Tens of thousands</li>
              </ul>
            </div>

            <div className="bg-white rounded-lg p-6 shadow-md">
              <h3 className="text-xl font-semibold mb-2">100 kt (Modern warhead)</h3>
              <p className="text-gray-600 mb-3">Typical yield of modern strategic warheads</p>
              <ul className="space-y-1 text-gray-700">
                <li>• Fireball radius: ~380 meters</li>
                <li>• Heavy blast damage: ~2.2 km radius</li>
                <li>• Moderate damage: ~5.4 km radius</li>
                <li>• Estimated casualties: Hundreds of thousands</li>
              </ul>
            </div>

            <div className="bg-white rounded-lg p-6 shadow-md">
              <h3 className="text-xl font-semibold mb-2">1 Mt (Megaton-class)</h3>
              <p className="text-gray-600 mb-3">Large strategic weapon</p>
              <ul className="space-y-1 text-gray-700">
                <li>• Fireball radius: ~820 meters</li>
                <li>• Heavy blast damage: ~4.7 km radius</li>
                <li>• Moderate damage: ~11.6 km radius</li>
                <li>• Estimated casualties: Millions</li>
              </ul>
            </div>
          </div>
        </section>

        <section className="mb-12">
          <h2 className="text-2xl font-semibold mb-4">Key Infrastructure at Risk</h2>
          <div className="bg-white rounded-lg p-6 shadow-md">
            <ul className="list-disc list-inside space-y-2 text-gray-700">
              <li>Government buildings and administrative centers</li>
              <li>Hospitals and medical facilities</li>
              <li>Transportation hubs (airports, train stations)</li>
              <li>Power plants and electrical grid</li>
              <li>Water treatment facilities</li>
              <li>Communication infrastructure</li>
              <li>Emergency response centers</li>
            </ul>
          </div>
        </section>

        <section className="mb-12">
          <h2 className="text-2xl font-semibold mb-4">Historical Context</h2>
          <div className="bg-white rounded-lg p-6 shadow-md">
            <p className="text-gray-700 mb-4">
              During the Cold War, major cities like {location.name} were primary targets in nuclear war 
              planning. Multiple warheads were often assigned to single cities to ensure destruction 
              despite missile defense systems.
            </p>
            <p className="text-gray-700">
              Today, although tensions have decreased, thousands of nuclear weapons remain on high alert 
              worldwide. Understanding the potential consequences remains crucial for informed public 
              discourse on nuclear policy.
            </p>
          </div>
        </section>

        <div className="text-center">
          <Link 
            href={simulationUrl}
            className="inline-block bg-blue-600 text-white px-8 py-3 rounded-lg text-lg font-semibold hover:bg-blue-700 transition"
          >
            Run Interactive Simulation for {location.name}
          </Link>
        </div>

        <div className="mt-12 p-4 bg-gray-100 rounded text-sm text-gray-600">
          <p className="font-semibold mb-2">Important Notes:</p>
          <ul className="list-disc list-inside space-y-1">
            <li>All casualty figures are estimates based on average population density</li>
            <li>Actual effects would vary based on weather, terrain, and time of day</li>
            <li>This simulation does not account for long-term radiation effects</li>
            <li>Medical infrastructure collapse would significantly increase casualties</li>
          </ul>
        </div>
      </main>
    </div>
  )
}