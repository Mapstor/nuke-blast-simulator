// lib/utils/format.ts

export function formatNumber(num: number): string {
  if (num >= 1_000_000) {
    return `${(num / 1_000_000).toFixed(1)}M`
  }
  if (num >= 1_000) {
    return `${(num / 1_000).toFixed(0)}K`
  }
  return num.toLocaleString()
}

export function formatDistance(km: number): string {
  if (km < 1) {
    return `${(km * 1000).toFixed(0)} m`
  }
  return `${km.toFixed(2)} km`
}

export function formatYield(kilotons: number): string {
  if (kilotons >= 1000) {
    return `${(kilotons / 1000).toFixed(1)} Mt`
  }
  return `${kilotons.toLocaleString()} kt`
}