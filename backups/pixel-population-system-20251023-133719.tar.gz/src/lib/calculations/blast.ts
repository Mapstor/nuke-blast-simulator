// lib/calculations/blast.ts

export function calculateFireball(yieldKt: number, burstType: 'air' | 'surface' = 'air'): number {
  // Fireball radius in km
  // Surface bursts have slightly smaller fireballs due to ground absorption
  const baseRadius = 0.28 * Math.pow(yieldKt, 0.33)
  return burstType === 'surface' ? baseRadius * 0.9 : baseRadius
}

export function calculateAirBlast(yieldKt: number, burstType: 'air' | 'surface' = 'air') {
  // Air bursts are optimized for maximum blast damage
  // Surface bursts lose ~30% of blast energy to crater formation
  const multiplier = burstType === 'surface' ? 0.7 : 1.0
  
  return {
    severe: 0.28 * Math.pow(yieldKt, 0.33) * multiplier, // 20 PSI
    moderate: 1.03 * Math.pow(yieldKt, 0.33) * multiplier, // 5 PSI
    light: 2.93 * Math.pow(yieldKt, 0.33) * multiplier // 1 PSI
  }
}

export function calculateThermalRadiation(yieldKt: number, burstType: 'air' | 'surface' = 'air') {
  // Surface bursts have reduced thermal effects due to ground absorption
  const multiplier = burstType === 'surface' ? 0.8 : 1.0
  
  return {
    thirdDegree: 0.67 * Math.pow(yieldKt, 0.41) * multiplier,
    secondDegree: 1.2 * Math.pow(yieldKt, 0.41) * multiplier
  }
}

export function calculateFallout(yieldKt: number, burstType: 'air' | 'surface' = 'air'): number {
  // Surface bursts create 10-20x more fallout than air bursts
  // Air bursts produce minimal fallout (mostly from neutron activation)
  if (burstType === 'air') {
    // Minimal fallout for air burst
    return 0.5 * Math.pow(yieldKt, 0.2)
  } else {
    // Massive fallout for surface burst
    return 8.0 * Math.pow(yieldKt, 0.35)
  }
}