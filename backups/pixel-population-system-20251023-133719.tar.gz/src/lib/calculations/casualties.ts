// lib/calculations/casualties.ts

import pixelPopulationService, { CasualtyZone } from '@/lib/services/pixelPopulation'

// Legacy function for backwards compatibility
export function calculateCasualties(
  radius: number, // km
  centerLat: number,
  centerLng: number,
  density: number, // per km²
  mortalityRate: number // 0-1
): number {
  const area = Math.PI * Math.pow(radius, 2)
  return Math.round(area * density * mortalityRate)
}

// Enhanced pixel-based casualty calculation
export function calculatePixelBasedCasualties(
  centerLat: number,
  centerLng: number,
  effectZones: Array<{
    name: string
    radius: number
    mortalityRate: number
    injuryRate: number
  }>
): CasualtyZone[] {
  return pixelPopulationService.calculateCasualtiesForZones(
    centerLat, 
    centerLng,
    effectZones.map(zone => ({
      name: zone.name,
      radius: zone.radius,
      mortality: zone.mortalityRate,
      injury: zone.injuryRate
    }))
  )
}

// Comprehensive casualty calculation for nuclear detonation
export function calculateNuclearCasualties(
  centerLat: number,
  centerLng: number,
  yield_kt: number,
  burstType: 'air' | 'surface' = 'air'
) {
  // Calculate effect radii based on yield
  const fireballRadius = 0.15 * Math.pow(yield_kt, 0.4)
  const severeBlastRadius = 1.15 * Math.pow(yield_kt, 0.4) 
  const moderateBlastRadius = 1.8 * Math.pow(yield_kt, 0.4)
  const lightBlastRadius = 2.8 * Math.pow(yield_kt, 0.4)
  const thermal3rdRadius = 2.2 * Math.pow(yield_kt, 0.4)
  const thermal2ndRadius = 3.5 * Math.pow(yield_kt, 0.4)
  
  // Define effect zones with realistic mortality/injury rates
  const zones = [
    {
      name: 'Fireball',
      radius: fireballRadius,
      mortalityRate: 1.0,
      injuryRate: 0.0
    },
    {
      name: 'Severe blast damage',
      radius: severeBlastRadius, 
      mortalityRate: 0.98,
      injuryRate: 0.02
    },
    {
      name: 'Moderate blast damage',
      radius: moderateBlastRadius,
      mortalityRate: 0.50,
      injuryRate: 0.40
    },
    {
      name: 'Light blast damage', 
      radius: lightBlastRadius,
      mortalityRate: 0.05,
      injuryRate: 0.45
    },
    {
      name: '3rd degree burns',
      radius: thermal3rdRadius,
      mortalityRate: 0.95,
      injuryRate: 0.05
    },
    {
      name: '2nd degree burns',
      radius: thermal2ndRadius,
      mortalityRate: 0.20,
      injuryRate: 0.70
    }
  ]
  
  // Add fallout zone for surface bursts
  if (burstType === 'surface') {
    const falloutRadius = 8.0 * Math.pow(yield_kt, 0.4)
    zones.push({
      name: 'Fallout (lethal)',
      radius: falloutRadius,
      mortalityRate: 0.30,
      injuryRate: 0.60
    })
  }
  
  return calculatePixelBasedCasualties(centerLat, centerLng, zones)
}

// Mortality rates by blast type (legacy)
export const MORTALITY_RATES = {
  fireball: 1.0,
  severe: 0.98,
  moderate: 0.50,
  light: 0.05,
  thermal3rd: 0.95,
  thermal2nd: 0.20,
  fallout: 0.30
}