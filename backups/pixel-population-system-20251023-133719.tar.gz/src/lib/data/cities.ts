// lib/data/cities.ts
// Preset locations for quick access - actual city data comes from Leaflet/OSM

import { Location } from '@/lib/types'

export const presetLocations: Location[] = [
  {
    name: 'New York',
    lat: 40.7128,
    lng: -74.0060,
    density: 10_194 // Approximate for casualty calculations
  },
  {
    name: 'London',
    lat: 51.5074,
    lng: -0.1278,
    density: 5_701
  },
  {
    name: 'Tokyo',
    lat: 35.6762,
    lng: 139.6503,
    density: 6_158
  },
  {
    name: 'Moscow',
    lat: 55.7558,
    lng: 37.6173,
    density: 4_950
  },
  {
    name: 'Washington DC',
    lat: 38.9072,
    lng: -77.0369,
    density: 4_600
  }
]

// Default density for unknown areas (global average urban density)
export const DEFAULT_URBAN_DENSITY = 3_500 // per km²