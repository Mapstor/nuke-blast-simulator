// store/simulatorStore.ts

import { create } from 'zustand'
import { Bomb, BlastResults } from '@/lib/types'
import { PopulationData } from '@/lib/services/populationGrid'

interface SimulatorState {
  selectedBomb: Bomb | null
  detonationPoint: { lat: number; lng: number } | null
  customYield: number
  results: BlastResults | null
  burstType: 'air' | 'surface'
  populationData: PopulationData | null
  
  // Animation state
  animationPhase: 'idle' | 'exploding' | 'showing-fireball' | 'showing-heavy-blast' | 'showing-moderate-blast' | 'showing-light-blast' | 'showing-thermal' | 'showing-fallout' | 'complete'
  isAnimating: boolean
  
  // Comparison mode
  comparisonMode: boolean
  comparisonBomb: Bomb | null
  comparisonResults: BlastResults | null
  
  setSelectedBomb: (bomb: Bomb) => void
  setDetonationPoint: (point: { lat: number; lng: number }) => void
  setCustomYield: (yieldKt: number) => void
  setResults: (results: BlastResults) => void
  setBurstType: (burstType: 'air' | 'surface') => void
  setPopulationData: (data: PopulationData | null) => void
  
  // Animation actions
  setAnimationPhase: (phase: SimulatorState['animationPhase']) => void
  setIsAnimating: (isAnimating: boolean) => void
  startExplosionSequence: () => void
  
  // Comparison actions
  setComparisonMode: (enabled: boolean) => void
  setComparisonBomb: (bomb: Bomb | null) => void
  setComparisonResults: (results: BlastResults | null) => void
  
  reset: () => void
}

export const useSimulatorStore = create<SimulatorState>((set, get) => ({
  selectedBomb: null,
  detonationPoint: null,
  customYield: 100,
  results: null,
  burstType: 'air',
  populationData: null,
  
  animationPhase: 'idle',
  isAnimating: false,
  
  comparisonMode: false,
  comparisonBomb: null,
  comparisonResults: null,
  
  setSelectedBomb: (bomb) => set({ selectedBomb: bomb }),
  setDetonationPoint: (point) => set({ detonationPoint: point }),
  setCustomYield: (yieldKt) => set({ customYield: yieldKt }),
  setResults: (results) => set({ results: results }),
  setBurstType: (burstType) => set({ burstType: burstType }),
  setPopulationData: (data) => set({ populationData: data }),
  
  setAnimationPhase: (phase) => set({ animationPhase: phase }),
  setIsAnimating: (isAnimating) => set({ isAnimating: isAnimating }),
  
  startExplosionSequence: () => {
    const phases: SimulatorState['animationPhase'][] = [
      'exploding',
      'showing-fireball',
      'showing-heavy-blast',
      'showing-moderate-blast', 
      'showing-light-blast',
      'showing-thermal',
      'showing-fallout',
      'complete'
    ]
    
    set({ isAnimating: true, animationPhase: 'exploding' })
    
    // Progress through phases with delays - faster timing
    phases.forEach((phase, index) => {
      setTimeout(() => {
        const state = get()
        if (state.isAnimating) {
          set({ animationPhase: phase })
          if (phase === 'complete') {
            set({ isAnimating: false })
          }
        }
      }, index * 400) // 400ms between each phase (3.2s total)
    })
  },
  
  setComparisonMode: (enabled) => set({ comparisonMode: enabled }),
  setComparisonBomb: (bomb) => set({ comparisonBomb: bomb }),
  setComparisonResults: (results) => set({ comparisonResults: results }),
  
  reset: () => set({
    selectedBomb: null,
    detonationPoint: null,
    customYield: 100,
    results: null,
    burstType: 'air',
    populationData: null,
    animationPhase: 'idle',
    isAnimating: false,
    comparisonMode: false,
    comparisonBomb: null,
    comparisonResults: null
  })
}))